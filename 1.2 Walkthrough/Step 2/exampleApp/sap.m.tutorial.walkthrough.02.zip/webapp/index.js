sap.ui.define([

], function () {
	"use strict";

	/* eslint-disable no-alert */
	alert("UI5 is ready");
	/* eslint-enable no-alert */
});
